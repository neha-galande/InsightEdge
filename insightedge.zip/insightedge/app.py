import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session,jsonify
import qrcode
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Initialize Database
def init_db():
    conn = sqlite3.connect('reusable_cup_system.db')
    c = conn.cursor()

    # Create users table (includes hotels)
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('customer', 'hotel', 'admin')),
        qr_code TEXT
    )''')

    # Points table
    c.execute('''CREATE TABLE IF NOT EXISTS points (
        user_id INTEGER,
        hotel_id INTEGER,
        points INTEGER DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (hotel_id) REFERENCES users(id),
        PRIMARY KEY (user_id, hotel_id)
    )''')

    conn.commit()
    conn.close()


def get_db_connection():
    conn = sqlite3.connect('reusable_cup_system.db')
    conn.row_factory = sqlite3.Row
    return conn


# Generate a QR code for the hotel if it does not exist
def generate_qr_for_hotel(hotel_id):
    conn = get_db_connection()
    qr_code_path = f'static/qr_code_hotel_{hotel_id}.png'

    # Generate QR code only if it doesn't exist for the hotel
    hotel = conn.execute('SELECT * FROM users WHERE id = ? AND role = "hotel"', (hotel_id,)).fetchone()
    if hotel and not hotel['qr_code']:
        # Create the QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(f"http://localhost:5000/customer/scan_qr/{hotel_id}")
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        img.save(qr_code_path)

        # Update the users table with the path to the QR code
        conn.execute('UPDATE users SET qr_code = ? WHERE id = ?', (qr_code_path, hotel_id))
        conn.commit()

    conn.close()
    return qr_code_path


@app.route('/')
def home():
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']

        conn = get_db_connection()
        existing_user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        
        if existing_user:
            conn.close()
            return "Username already exists. Please choose a different one."
        
        conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', 
                     (username, password, role))
        conn.commit()
        conn.close()

        return redirect(url_for('home'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?', 
                            (username, password)).fetchone()
        conn.close()

        if user:
            session['user_id'] = user['id']
            session['role'] = user['role']
            
            if user['role'] == 'customer':
                return redirect(url_for('customer_dashboard'))
            elif user['role'] == 'hotel':
                qr_code_path = generate_qr_for_hotel(user['id'])
                return redirect(url_for('hotel_dashboard', hotel_id=user['id'], qr_code=qr_code_path))
            elif user['role'] == 'admin':
                return redirect(url_for('admin_dashboard'))
        else:
            return "Invalid credentials. Please try again."

    return render_template('login.html')


@app.route('/hotel/<int:hotel_id>/dashboard')
def hotel_dashboard(hotel_id):
    # Fetch hotel and customers
    conn = get_db_connection()
    hotel = conn.execute('SELECT * FROM users WHERE id = ? AND role = "hotel"', (hotel_id,)).fetchone()

    if not hotel:
        conn.close()
        return "Hotel not found", 404

    # Fetch customers associated with the hotel
    customers = conn.execute("""
        SELECT u.username, p.points 
        FROM users u
        JOIN points p ON u.id = p.user_id
        WHERE p.hotel_id = ?
    """, (hotel_id,)).fetchall()

    conn.close()

    return render_template('hotel_dashboard.html', hotel_id=hotel_id, customers=customers, qr_code=hotel['qr_code'])


@app.route('/customer/dashboard')
def customer_dashboard():
    user_id = session.get('user_id')
    
    if not user_id:
        return redirect(url_for('login'))  # Ensure the customer is logged in
    
    conn = get_db_connection()
    
    # Get total points for the customer from all hotels
    total_points = conn.execute('''SELECT SUM(points) FROM points WHERE user_id = ?''', (user_id,)).fetchone()[0] or 0
    
    # Get points from each hotel
    hotels_points = conn.execute('''
        SELECT u.id AS hotel_id, u.username AS hotel_name, p.points 
        FROM points p
        JOIN users u ON p.hotel_id = u.id
        WHERE p.user_id = ?
    ''', (user_id,)).fetchall()

    conn.close()

    # Pass hotel_id as part of the context to the template
    return render_template('customer_dashboard.html', total_points=total_points, hotels_points=hotels_points, hotel_id=hotels_points[0]['hotel_id'] if hotels_points else None)


@app.route('/customer/scan_qr/<int:hotel_id>', methods=['GET'])
def scan_qr(hotel_id):
    user_id = session.get('user_id')
    
    if not user_id:
        return redirect(url_for('login'))  # Ensure the customer is logged in
    
    conn = get_db_connection()
    
    # Get customer and hotel data
    customer = conn.execute('SELECT * FROM users WHERE id = ? AND role = "customer"', (user_id,)).fetchone()
    if not customer:
        return jsonify({'message': 'Invalid customer'}), 404
    
    hotel = conn.execute('SELECT * FROM users WHERE id = ? AND role = "hotel"', (hotel_id,)).fetchone()
    if not hotel:
        return jsonify({'message': 'Invalid hotel'}), 404
    
    # Get current points for the customer at this hotel
    customer_points = conn.execute('''SELECT points FROM points WHERE user_id = ? AND hotel_id = ?''', (user_id, hotel_id)).fetchone()
    
    if customer_points:
        points = customer_points['points']
    else:
        points = 0
    
    # Increment the points for this customer and hotel by 1
    conn.execute('''INSERT INTO points (user_id, hotel_id, points) 
                    VALUES (?, ?, 1) 
                    ON CONFLICT(user_id, hotel_id) 
                    DO UPDATE SET points = points + 1''', (user_id, hotel_id))
    conn.commit()
    
    # Fetch updated customer points for the hotel
    updated_points = conn.execute('''SELECT points FROM points WHERE user_id = ? AND hotel_id = ?''', (user_id, hotel_id)).fetchone()['points']
    
    conn.close()

    return jsonify({
        'message': 'QR code successfully scanned!',
        'hotel_name': hotel['username'],
        'current_points': points,
        'updated_points': updated_points
    })






@app.route('/admin/dashboard')
def admin_dashboard():
    conn = get_db_connection()
    users = conn.execute('SELECT * FROM users').fetchall()
    conn.close()
    return render_template('admin_dashboard.html', users=users)


@app.route('/hotel/<int:hotel_id>/qr')
def show_qr(hotel_id):
    conn = get_db_connection()
    hotel_data = conn.execute('SELECT qr_code FROM users WHERE id = ? AND role = "hotel"', (hotel_id,)).fetchone()
    conn.close()

    if hotel_data and hotel_data['qr_code']:
        qr_code_path = hotel_data['qr_code']
        return render_template('show_qr.html', qr_code=qr_code_path)
    else:
        return "QR code not found for this hotel.", 404


# Ensure the static folder exists for storing QR codes
if not os.path.exists('static'):
    os.makedirs('static')


if __name__ == '__main__':
    init_db()  # Initialize the database
    app.run(debug=True)
