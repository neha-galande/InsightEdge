@app.route('/hotel/<int:hotel_id>/qr')
# def show_qr(hotel_id):
#     hotel = get_hotel_from_db(hotel_id)
#     if not hotel:
#         return "Hotel not found", 404

#     qr_code_path = f'static/qr_code_hotel_{hotel_id}.png'

#     # Generate the QR code if it doesn't already exist
#     if not os.path.exists(qr_code_path):
#         qr = qrcode.QRCode(
#             version=1,
#             error_correction=qrcode.constants.ERROR_CORRECT_L,
#             box_size=10,
#             border=4,
#         )
#         qr.add_data(f"http://localhost:5000/customer/scan_qr/{hotel_id}")
#         qr.make(fit=True)

#         img = qr.make_image(fill_color="black", back_color="white")
#         img.save(qr_code_path)

#     return render_template('show_qr.html', qr_code=qr_code_path, hotel_name=hotel['hotel_name'])